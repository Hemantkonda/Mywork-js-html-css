// loops - repeat
// for loop
// while loop
// do while loop

// for(intialize-(start value); condition; (increment/decrement-> modifiers / updation))

// problem statement: 1 to 5
// let i = 1;
// for (i; i < 0; i = i + 2) {
//   console.log(i);
// }
// loops
// 1. entry controlled loop (example- for loop, while loop)
// 2. exit controlled loop (example- do while loop)

// problem statement: 1 to 5 (while loop)
// while(condition) body {}

// initialize
// let i = 10;
// while (i <= 5) {
//   console.log(i);
//   // modifier / update
//   i++;
// }

// do while loop
// do {
//     // code
// }while(condition)

// problem statement: 1 to 5 (do while loop)
// initilize
// let i = 10;
// do {
//   console.log(i);
//   // modifier
//   i++;
// } while (i < 6);
// atleast it will run one time

// break and continue

// break

// problem statement: 100 (do while loop)
// let i = 1;
// for (i; i <= 100; i++) {
//   //   console.log(i);
//   if (i == 50) {
//     break;
//   }
// }
// console.log(i);

// continue (skip the value)
// let i = 1;
// for (i; i <= 20; i++) {
//   if (i == 10) {
//     continue;
//   }
//   console.log(i);
// }

// print the table of 2
// 2 * 1 = 2
// let number = 5;
// for (let i = 1; i <= 10; i++) {
//   console.log(number + "*" + i + "=" + number * i);
// }
